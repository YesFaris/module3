# Exercice dirigé: Template module 3

## Consignes
- Construre le template par défaut du module 3
- Modifier la feuille de style commune (faire la version 3)
